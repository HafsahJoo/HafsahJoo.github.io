// Low-poly toy diorama of Hafsah's room. createRoom(container, opts) -> api
import * as THREE from 'https://unpkg.com/three@0.184.0/build/three.module.js';

const V3 = THREE.Vector3;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const easeOutBack = (t) => { const c1 = 1.5, c3 = c1 + 1; return 1 + c3 * Math.pow(t - 1, 3) + c1 * Math.pow(t - 1, 2); };
const easeInOut = (t) => (t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2);
function rng(seed) { return () => { seed = (seed + 0x6d2b79f5) | 0; let t = Math.imul(seed ^ (seed >>> 15), 1 | seed); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }

export const DEFAULT_PALETTE = {
  wall: '#ffd9b8', wallSide: '#f6c79c', trim: '#2b2a4a', floor: '#d39a66', floor2: '#c88d59', floorEdge: '#8a5a3a',
  wood: '#c98d5a', woodDark: '#8a5a3a', frame: '#2b2a4a', cabinet: '#fff6ea', beige: '#efe4cf', beigeDark: '#d8c9ad',
  dark: '#26243a', white: '#fffaf2', a1: '#ef5a3c', a2: '#3b5bdb', a3: '#f7b733', a4: '#3fbf8f', a5: '#ff8fb1',
  leaf: '#4caf6e', leaf2: '#2f8f58', pot: '#ef5a3c', rug: '#3b5bdb', rug2: '#f7b733', cork: '#d9a86c',
  sea: '#2fb3c9', sand: '#f3dcae', mountain: '#3c8f5a', trunk: '#8a5a3a', sun: '#ffd24a', moon: '#f4f1ff',
  skyDayTop: '#7cc8ff', skyDayBot: '#ffe3c2', skyNightTop: '#141a46', skyNightBot: '#3b2f6b',
  led: '#ff5fa2', screenBg: '#121a33', globeSea: '#3b8fe0', globeLand: '#5cc46e', beanbag: '#ff8fb1',
  hemiDay: '#fff3e4', hemiNight: '#6a64c8',
};

export const FOCUS = {
  pc: { p: [-2.2, 1.6, -2.5], yaw: 0.32, pitch: 0.28, dist: 6.2, zoom: 2.5 },
  switch: { p: [-1.35, 1.15, -2.3], yaw: 0.45, pitch: 0.85, dist: 3.6, zoom: 4.0 },
  board: { p: [-1.85, 2.6, -3.2], yaw: 0.22, pitch: 0.22, dist: 5.4, zoom: 2.9 },
  window: { p: [1.3, 2.1, -3.3], yaw: 0.16, pitch: 0.2, dist: 6.4, zoom: 2.4 },
  globe: { p: [1.8, 1.2, -2.85], yaw: 0.45, pitch: 0.38, dist: 4.4, zoom: 3.4 },
  shelf: { p: [-2.95, 1.35, -0.75], yaw: 1.12, pitch: 0.26, dist: 7.6, zoom: 1.9 },
  lego: { p: [-2.95, 2.9, -0.75], yaw: 0.95, pitch: 0.45, dist: 4.2, zoom: 3.4 },
  certs: { p: [-3.2, 2.5, 1.65], yaw: 1.28, pitch: 0.16, dist: 5.6, zoom: 2.5 },
};

export function createRoom(container, opts = {}) {
  const P = Object.assign({}, DEFAULT_PALETTE, opts.palette || {});
  const reduce = window.matchMedia && matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isIso = opts.camera === 'iso';
  const geos = new Set(), mats = {};
  const C = (h) => new THREE.Color(h);

  function rbox(w, h, d, r = 0.05) {
    r = Math.max(0.002, Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001));
    const ww = w - 2 * r, hh = h - 2 * r, rc = Math.min(r * 0.9, ww / 2, hh / 2);
    const s = new THREE.Shape(), x = -ww / 2, y = -hh / 2;
    if (rc > 0.002) {
      s.moveTo(x + rc, y); s.lineTo(x + ww - rc, y); s.quadraticCurveTo(x + ww, y, x + ww, y + rc);
      s.lineTo(x + ww, y + hh - rc); s.quadraticCurveTo(x + ww, y + hh, x + ww - rc, y + hh);
      s.lineTo(x + rc, y + hh); s.quadraticCurveTo(x, y + hh, x, y + hh - rc);
      s.lineTo(x, y + rc); s.quadraticCurveTo(x, y, x + rc, y);
    } else { s.moveTo(x, y); s.lineTo(x + ww, y); s.lineTo(x + ww, y + hh); s.lineTo(x, y + hh); s.lineTo(x, y); }
    const dd = Math.max(0.0005, d - 2 * r);
    const g = new THREE.ExtrudeGeometry(s, { depth: dd, bevelEnabled: true, bevelThickness: r, bevelSize: r, bevelSegments: 3, curveSegments: 3 });
    g.translate(0, 0, -dd / 2); geos.add(g); return g;
  }
  const box = (w, h, d) => { const g = new THREE.BoxGeometry(w, h, d); geos.add(g); return g; };
  const G = (g) => { geos.add(g); return g; };
  const M = (k, o = {}) => { const key = k + JSON.stringify(o); return (mats[key] ||= new THREE.MeshStandardMaterial({ color: P[k] || k, roughness: 0.78, metalness: 0, ...o })); };
  function add(parent, geo, mat, x = 0, y = 0, z = 0, o = {}) {
    const m = new THREE.Mesh(geo, mat); m.position.set(x, y, z);
    m.castShadow = o.cast ?? true; m.receiveShadow = o.recv ?? true;
    if (o.rx) m.rotation.x = o.rx; if (o.ry) m.rotation.y = o.ry; if (o.rz) m.rotation.z = o.rz;
    if (o.s) m.scale.set(o.s[0], o.s[1], o.s[2]);
    parent.add(m); return m;
  }
  function rod(parent, a, b, r, mat, seg = 8) {
    const va = new V3(...a), vb = new V3(...b);
    const m = new THREE.Mesh(G(new THREE.CylinderGeometry(r, r, va.distanceTo(vb), seg)), mat);
    m.position.copy(va).add(vb).multiplyScalar(0.5);
    m.quaternion.setFromUnitVectors(new V3(0, 1, 0), vb.clone().sub(va).normalize());
    m.castShadow = true; parent.add(m); return m;
  }

  // renderer / scene
  const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: 'high-performance', preserveDrawingBuffer: true });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.toneMapping = THREE.NeutralToneMapping; renderer.toneMappingExposure = 1.0;
  renderer.outputColorSpace = THREE.SRGBColorSpace; renderer.setClearColor(0x000000, 0);
  const canvas = renderer.domElement;
  Object.assign(canvas.style, { width: '100%', height: '100%', display: 'block', touchAction: 'pan-y', cursor: 'grab', outline: 'none' });
  container.appendChild(canvas);
  const scene = new THREE.Scene();
  const world = new THREE.Group(); scene.add(world);
  const animated = []; const inter = {};
  let delayCursor = 0.5;
  function piece(id, x, y, z, ry = 0, kind = 'drop') {
    const g = new THREE.Group(); g.position.set(x, y, z); g.rotation.y = ry;
    g.userData = { id, baseY: y, delay: kind === 'scale' ? 0.05 : (delayCursor += 0.075), kind, h: 0 };
    world.add(g); animated.push(g); if (id) inter[id] = g; return g;
  }

  const W = 7, D = 7, H = 4.2, T = 0.25, X0 = -3.5, Z0 = -3.5;
  const WX0 = 0.3, WX1 = 2.3, WY0 = 1.5, WY1 = 3.1, WCX = 1.3, WCY = 2.3, BZ = Z0 + T / 2;

  // ---------- shell ----------
  const shell = piece(null, 0, 0, 0, 0, 'scale');
  add(shell, rbox(W, 0.4, D, 0.1), M('floorEdge'), 0, -0.2, 0);
  for (let i = 0; i < 7; i++) add(shell, box(0.93, 0.03, 6.65), M(i % 2 ? 'floor2' : 'floor'), -3.25 + 0.475 + i * 0.95, 0, 0.075, { cast: false });
  add(shell, box(WX0 - X0, H, T), M('wall'), (X0 + WX0) / 2, H / 2, BZ);
  add(shell, box(3.5 - WX1, H, T), M('wall'), (WX1 + 3.5) / 2, H / 2, BZ);
  add(shell, box(WX1 - WX0, WY0, T), M('wall'), WCX, WY0 / 2, BZ);
  add(shell, box(WX1 - WX0, H - WY1, T), M('wall'), WCX, (WY1 + H) / 2, BZ);
  add(shell, box(T, H, D - T), M('wallSide'), X0 + T / 2, H / 2, Z0 + T + (D - T) / 2);
  add(shell, rbox(W + 0.06, 0.14, T + 0.1, 0.045), M('trim'), 0.0, H + 0.07, BZ);
  add(shell, rbox(T + 0.1, 0.14, D + 0.02, 0.045), M('trim'), X0 + T / 2, H + 0.07, 0.0);
  add(shell, rbox(0.13, H + 0.14, T + 0.1, 0.045), M('trim'), 3.5 - 0.035, H / 2, BZ);
  add(shell, rbox(T + 0.1, H + 0.14, 0.13, 0.045), M('trim'), X0 + T / 2, H / 2, 3.5 - 0.035);
  add(shell, box(W - T, 0.16, 0.04), M('trim'), X0 + T + (W - T) / 2, 0.08, Z0 + T + 0.02);
  add(shell, box(0.04, 0.16, D - T), M('trim'), X0 + T + 0.02, 0.08, Z0 + T + (D - T) / 2);
  const ledMat = new THREE.MeshStandardMaterial({ color: P.led, emissive: P.led, emissiveIntensity: 0, roughness: 0.4 });
  add(shell, box(W - T - 0.2, 0.05, 0.05), ledMat, X0 + T + (W - T) / 2, H - 0.12, Z0 + T + 0.04, { cast: false });
  add(shell, box(0.05, 0.05, D - T - 0.2), ledMat, X0 + T + 0.04, H - 0.12, Z0 + T + (D - T) / 2, { cast: false });
  // rug
  add(shell, G(new THREE.CylinderGeometry(1.7, 1.7, 0.03, 40)), M('rug'), 0.9, 0.03, 0.9, { s: [1, 1, 0.72], cast: false });
  add(shell, G(new THREE.CylinderGeometry(1.15, 1.15, 0.03, 40)), M('rug2'), 0.9, 0.045, 0.9, { s: [1, 1, 0.72], cast: false });

  // ---------- outside the window (Mauritius view) ----------
  const outside = new THREE.Group(); outside.position.set(WCX, WCY, Z0); outside.userData.id = 'window'; world.add(outside);
  const skyMat = new THREE.ShaderMaterial({
    uniforms: { top: { value: C(P.skyDayTop) }, bot: { value: C(P.skyDayBot) } },
    vertexShader: 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }',
    fragmentShader: 'uniform vec3 top; uniform vec3 bot; varying vec2 vUv; void main(){ gl_FragColor = vec4(mix(bot, top, smoothstep(0.15, 0.95, vUv.y)), 1.0);\n#include <colorspace_fragment>\n}',
  });
  const nope = { cast: false, recv: false };
  add(outside, G(new THREE.PlaneGeometry(2.8, 2.45)), skyMat, -0.2, -0.075, -0.45, nope);
  add(outside, box(2.8, 0.55, 0.36), M('sea', { roughness: 0.35 }), -0.2, -0.725, -0.25, nope);
  add(outside, box(2.8, 0.2, 0.08), M('sand'), -0.2, -0.68, -0.045, nope);
  add(outside, G(new THREE.CylinderGeometry(0.1, 0.42, 0.62, 5)), M('mountain', { flatShading: true }), -0.35, -0.16, -0.36, { ...nope, s: [1.7, 1, 0.5] });
  add(outside, G(new THREE.CylinderGeometry(0.08, 0.3, 0.3, 5)), M('mountain', { flatShading: true }), 0.35, -0.32, -0.38, { ...nope, s: [1.6, 1, 0.4] });
  const palm = new THREE.Group(); palm.position.set(0.72, -0.6, -0.12); outside.add(palm);
  rod(palm, [0, 0, 0], [0.05, 0.3, 0], 0.025, M('trunk')).castShadow = false;
  rod(palm, [0.05, 0.3, 0], [0.12, 0.6, 0], 0.022, M('trunk')).castShadow = false;
  for (let i = 0; i < 6; i++) {
    const a = (i / 6) * Math.PI * 2;
    const l = add(palm, G(new THREE.ConeGeometry(0.05, 0.36, 4)), M('leaf', { flatShading: true }), 0.12 + Math.cos(a) * 0.14, 0.58, Math.sin(a) * 0.08, nope);
    l.rotation.set(0, -a, Math.PI / 2 + 0.5); l.rotation.order = 'YXZ'; l.rotation.set(0.0, -a, -(Math.PI / 2 + 0.45));
  }
  const skyBasic = (c) => new THREE.MeshBasicMaterial({ color: c, transparent: true });
  const sun = add(outside, G(new THREE.SphereGeometry(0.2, 20, 14)), new THREE.MeshBasicMaterial({ color: P.sun }), 0, 0, -0.42, nope);
  const sunHalo = add(outside, G(new THREE.CircleGeometry(0.34, 32)), new THREE.MeshBasicMaterial({ color: P.sun, transparent: true, opacity: 0.25 }), 0, 0, -0.44, nope);
  const moon = add(outside, G(new THREE.SphereGeometry(0.15, 20, 14)), new THREE.MeshBasicMaterial({ color: P.moon }), 0, 0, -0.42, nope);
  const craterMat = new THREE.MeshBasicMaterial({ color: P.moonShade || '#cfc8ee' });
  [[0.05, 0.04, 0.035], [-0.05, -0.03, 0.025], [0.03, -0.07, 0.018]].forEach(([x, y, r]) => add(moon, G(new THREE.CircleGeometry(r, 14)), craterMat, x, y, 0.152, nope));
  const cloudMat = skyBasic('#ffffff');
  const clouds = new THREE.Group(); outside.add(clouds);
  [[-0.75, 0.55, 1], [0.15, 0.32, 0.8], [-1.2, 0.2, 0.7]].forEach(([x, y, s]) => {
    [[0, 0, 0.1], [0.11, 0.03, 0.08], [-0.1, -0.01, 0.07]].forEach(([dx, dy, r]) => add(clouds, G(new THREE.SphereGeometry(r * s, 10, 8)), cloudMat, x + dx * s, y + dy * s, -0.4, { ...nope, s: [1.4, 0.8, 0.3] }));
  });
  const starMat = skyBasic('#ffffff'); const stars = new THREE.Group(); outside.add(stars);
  const rs = rng(7);
  for (let i = 0; i < 16; i++) add(stars, G(new THREE.SphereGeometry(0.012 + rs() * 0.012, 6, 4)), starMat, -1.3 + rs() * 2.4, -0.3 + rs() * 1.3, -0.43, nope);

  // ---------- window frame ----------
  const win = piece('window', WCX, WCY, BZ);
  const fm = M('white');
  add(win, rbox(2.18, 0.12, T + 0.1, 0.03), fm, 0, 0.8, 0);
  add(win, rbox(2.18, 0.12, T + 0.1, 0.03), fm, 0, -0.8, 0);
  add(win, rbox(0.12, 1.72, T + 0.1, 0.03), fm, -1.0, 0, 0);
  add(win, rbox(0.12, 1.72, T + 0.1, 0.03), fm, 1.0, 0, 0);
  add(win, box(0.05, 1.6, 0.05), fm, 0, 0, 0.02);
  add(win, box(2.0, 0.05, 0.05), fm, 0, 0.2, 0.02);
  add(win, rbox(2.4, 0.08, 0.44, 0.03), fm, 0, -0.84, T / 2 + 0.1);
  const cactus = new THREE.Group(); cactus.position.set(0.72, -0.8, 0.2); win.add(cactus);
  add(cactus, G(new THREE.CylinderGeometry(0.07, 0.055, 0.12, 12)), M('a1'), 0, 0.06, 0);
  add(cactus, G(new THREE.CapsuleGeometry(0.045, 0.12, 4, 8)), M('leaf2'), 0, 0.2, 0);
  add(cactus, G(new THREE.CapsuleGeometry(0.025, 0.05, 4, 8)), M('leaf2'), 0.05, 0.22, 0, { rz: -0.9 });

  // ---------- desk ----------
  const desk = piece(null, -1.75, 0, -2.6);
  add(desk, rbox(2.7, 0.1, 1.25, 0.035), M('wood'), 0, 1.05, 0);
  add(desk, rbox(0.08, 1.0, 1.15, 0.02), M('woodDark'), -1.29, 0.5, 0);
  add(desk, rbox(0.62, 1.0, 1.15, 0.03), M('cabinet'), 1.02, 0.5, 0);
  for (let i = 0; i < 3; i++) {
    add(desk, rbox(0.54, 0.28, 0.03, 0.012), M(['a3', 'a4', 'a5'][i]), 1.02, 0.83 - i * 0.31, 0.585);
    add(desk, rbox(0.14, 0.03, 0.03, 0.012), M('dark'), 1.02, 0.86 - i * 0.31, 0.61);
  }

  // ---------- retro PC ----------
  const pc = piece('pc', -2.3, 1.1, -2.72);
  add(pc, rbox(0.55, 0.05, 0.45, 0.02), M('beigeDark'), 0, 0.025, -0.05);
  add(pc, rbox(1.0, 0.82, 0.62, 0.07), M('beige'), 0, 0.46, -0.02);
  add(pc, rbox(0.72, 0.58, 0.2, 0.06), M('beigeDark'), 0, 0.44, -0.4);
  add(pc, box(0.84, 0.64, 0.012), M('dark'), 0, 0.48, 0.292);
  const scr = makeScreen(P); geos.add(scr.tex);
  const screenMat = new THREE.MeshBasicMaterial({ map: scr.tex, toneMapped: false });
  add(pc, G(new THREE.PlaneGeometry(0.76, 0.57)), screenMat, 0, 0.48, 0.3, { cast: false });
  const pled = new THREE.MeshStandardMaterial({ color: P.a4, emissive: P.a4, emissiveIntensity: 1.2 });
  add(pc, G(new THREE.SphereGeometry(0.02, 8, 6)), pled, 0.4, 0.1, 0.29);
  add(pc, rbox(0.86, 0.045, 0.28, 0.02), M('beige'), 0.05, 0.023, 0.5);
  add(pc, box(0.78, 0.014, 0.2), M('beigeDark'), 0.05, 0.05, 0.5);
  add(pc, rbox(0.09, 0.045, 0.14, 0.035), M('beige'), 0.62, 0.022, 0.5);
  add(pc, rbox(0.38, 0.9, 0.75, 0.04), M('beige'), -0.48, -0.65, 0.12);
  add(pc, box(0.28, 0.045, 0.012), M('beigeDark'), -0.48, -0.32, 0.5);
  add(pc, box(0.28, 0.02, 0.012), M('dark'), -0.48, -0.42, 0.5);
  add(pc, G(new THREE.SphereGeometry(0.025, 8, 6)), pled, -0.38, -0.9, 0.5);

  // ---------- Switch 2 ----------
  const sw = piece('switch', -1.35, 1.1, -2.3, 0.22);
  add(sw, rbox(0.4, 0.035, 0.23, 0.012), M('dark'), 0, 0.02, 0);
  const swTex = makeSwitchScreen(P); geos.add(swTex);
  const swMat = new THREE.MeshBasicMaterial({ map: swTex, toneMapped: false });
  add(sw, G(new THREE.PlaneGeometry(0.34, 0.19)), swMat, 0, 0.039, 0, { rx: -Math.PI / 2, cast: false });
  add(sw, rbox(0.075, 0.04, 0.23, 0.02), M('a2'), -0.235, 0.02, 0);
  add(sw, rbox(0.075, 0.04, 0.23, 0.02), M('a1'), 0.235, 0.02, 0);
  add(sw, G(new THREE.CylinderGeometry(0.018, 0.018, 0.02, 10)), M('dark'), -0.235, 0.045, -0.04);
  add(sw, G(new THREE.CylinderGeometry(0.018, 0.018, 0.02, 10)), M('dark'), 0.235, 0.045, 0.04);

  // mug + lamp
  const mug = piece(null, -0.85, 1.1, -2.35);
  add(mug, G(new THREE.CylinderGeometry(0.085, 0.08, 0.2, 16)), M('a2'), 0, 0.1, 0);
  add(mug, G(new THREE.TorusGeometry(0.05, 0.015, 8, 16)), M('a2'), 0.09, 0.1, 0, { ry: 0 });
  add(mug, G(new THREE.CylinderGeometry(0.07, 0.07, 0.01, 16)), M('woodDark'), 0, 0.18, 0, { cast: false });
  const lamp = piece(null, -0.6, 1.1, -2.98);
  add(lamp, G(new THREE.CylinderGeometry(0.15, 0.17, 0.05, 20)), M('dark'), 0, 0.025, 0);
  rod(lamp, [0, 0.05, 0], [-0.12, 0.62, 0.08], 0.022, M('dark'));
  add(lamp, G(new THREE.SphereGeometry(0.04, 10, 8)), M('dark'), -0.12, 0.62, 0.08);
  rod(lamp, [-0.12, 0.62, 0.08], [-0.42, 0.76, 0.22], 0.02, M('dark'));
  const head = new THREE.Group(); head.position.set(-0.45, 0.74, 0.24); head.rotation.set(0.25, 0, -0.75); lamp.add(head);
  add(head, G(new THREE.ConeGeometry(0.15, 0.22, 20, 1, true)), M('a1', { side: THREE.DoubleSide }), 0, 0, 0);
  const bulbMat = new THREE.MeshStandardMaterial({ color: '#fff3d6', emissive: '#ffcf7a', emissiveIntensity: 0.2 });
  add(head, G(new THREE.SphereGeometry(0.06, 12, 8)), bulbMat, 0, -0.06, 0, { cast: false });

  // chair
  const chair = piece(null, -1.75, 0, -1.6, 0.3);
  for (let i = 0; i < 5; i++) { const a = (i / 5) * Math.PI * 2; rod(chair, [0, 0.1, 0], [Math.cos(a) * 0.36, 0.06, Math.sin(a) * 0.36], 0.025, M('dark')); add(chair, G(new THREE.SphereGeometry(0.045, 8, 6)), M('dark'), Math.cos(a) * 0.36, 0.045, Math.sin(a) * 0.36); }
  rod(chair, [0, 0.1, 0], [0, 0.58, 0], 0.04, M('dark'));
  add(chair, rbox(0.64, 0.12, 0.6, 0.055), M('a2'), 0, 0.62, 0);
  rod(chair, [0, 0.62, 0.22], [0, 0.82, 0.3], 0.03, M('dark'));
  add(chair, rbox(0.6, 0.66, 0.11, 0.05), M('a2'), 0, 1.06, 0.32, { rx: -0.12 });

  // cork board (notes)
  const board = piece('board', -1.85, 2.65, -3.25);
  add(board, rbox(1.7, 1.05, 0.06, 0.02), M('wood'), 0, 0, 0.03);
  add(board, box(1.56, 0.91, 0.02), M('cork'), 0, 0, 0.065, { cast: false });
  const rn = rng(3);
  const notes = [['a3', -0.55, 0.2], ['a5', -0.15, 0.25], ['white', 0.28, 0.18], ['a4', 0.6, 0.22], ['a2', -0.4, -0.22], ['a3', 0.05, -0.2], ['white', 0.5, -0.2]];
  notes.forEach(([c, x, y], i) => {
    const s = i === 2 || i === 6 ? 0.26 : 0.22;
    add(board, box(s, s, 0.006), M(c), x, y, 0.08, { rz: (rn() - 0.5) * 0.3, cast: false });
    add(board, G(new THREE.SphereGeometry(0.02, 8, 6)), M(i % 2 ? 'a1' : 'a2'), x, y + s / 2 - 0.03, 0.095);
  });

  // cabinet under window + globe + snake plant
  const cab = piece(null, WCX, 0, -2.88);
  add(cab, rbox(1.9, 0.82, 0.68, 0.04), M('cabinet'), 0, 0.41, 0);
  add(cab, rbox(0.86, 0.66, 0.02, 0.01), M('a2'), -0.46, 0.41, 0.345);
  add(cab, rbox(0.86, 0.66, 0.02, 0.01), M('a5'), 0.46, 0.41, 0.345);
  add(cab, G(new THREE.SphereGeometry(0.025, 8, 6)), M('dark'), -0.1, 0.45, 0.37);
  add(cab, G(new THREE.SphereGeometry(0.025, 8, 6)), M('dark'), 0.1, 0.45, 0.37);
  const globe = piece('globe', 1.8, 0.82, -2.85);
  add(globe, G(new THREE.CylinderGeometry(0.14, 0.17, 0.05, 20)), M('dark'), 0, 0.025, 0);
  rod(globe, [0, 0.05, 0], [0, 0.18, 0], 0.025, M('dark'));
  const tilt = new THREE.Group(); tilt.position.set(0, 0.5, 0); tilt.rotation.z = 0.41; globe.add(tilt);
  add(tilt, G(new THREE.TorusGeometry(0.35, 0.014, 6, 40, Math.PI)), M('a3', { metalness: 0.3, roughness: 0.4 }), 0, 0, 0, { rz: Math.PI / 2 });
  const spin = new THREE.Group(); tilt.add(spin);
  const gg = new THREE.IcosahedronGeometry(0.3, 2); geos.add(gg);
  { const pos = gg.attributes.position, cols = [], cs = C(P.globeSea), cl = C(P.globeLand);
    for (let i = 0; i < pos.count; i += 3) {
      const x = (pos.getX(i) + pos.getX(i + 1) + pos.getX(i + 2)) / 0.9, y = (pos.getY(i) + pos.getY(i + 1) + pos.getY(i + 2)) / 0.9, z = (pos.getZ(i) + pos.getZ(i + 1) + pos.getZ(i + 2)) / 0.9;
      const n = Math.sin(x * 3 + 1) + Math.sin(y * 2.6 + 2) + Math.sin(z * 2.9);
      const c = n > 0.75 ? cl : cs; for (let k = 0; k < 3; k++) cols.push(c.r, c.g, c.b);
    }
    gg.setAttribute('color', new THREE.Float32BufferAttribute(cols, 3)); }
  add(spin, gg, new THREE.MeshStandardMaterial({ vertexColors: true, flatShading: true, roughness: 0.6 }), 0, 0, 0);
  [[0.4, 1.0], [-0.35, 2.2], [0.75, 3.6], [0.1, 4.6], [-0.6, 5.5]].forEach(([lat, lon]) => {
    const d = new V3(Math.cos(lat) * Math.cos(lon), Math.sin(lat), Math.cos(lat) * Math.sin(lon));
    rod(spin, d.clone().multiplyScalar(0.29).toArray(), d.clone().multiplyScalar(0.36).toArray(), 0.006, M('dark'), 4);
    add(spin, G(new THREE.SphereGeometry(0.025, 8, 6)), M('a1'), ...d.clone().multiplyScalar(0.37).toArray());
  });
  const snake = piece(null, 0.75, 0.82, -2.85);
  add(snake, G(new THREE.CylinderGeometry(0.12, 0.09, 0.2, 12)), M('a3'), 0, 0.1, 0);
  for (let i = 0; i < 6; i++) { const a = (i / 6) * Math.PI * 2; add(snake, G(new THREE.ConeGeometry(0.035, 0.42 + (i % 3) * 0.08, 4)), M(i % 2 ? 'leaf' : 'leaf2', { flatShading: true }), Math.cos(a) * 0.05, 0.4, Math.sin(a) * 0.05, { rx: Math.sin(a) * 0.18, rz: -Math.cos(a) * 0.18 }); }

  // tall low-poly plant
  const tree = piece(null, 2.95, 0, -2.85);
  add(tree, G(new THREE.CylinderGeometry(0.26, 0.2, 0.5, 14)), M('pot'), 0, 0.25, 0);
  add(tree, G(new THREE.CylinderGeometry(0.23, 0.23, 0.02, 14)), M('woodDark'), 0, 0.49, 0, { cast: false });
  rod(tree, [0, 0.5, 0], [0.02, 1.4, 0], 0.03, M('trunk'));
  const fol = new THREE.Group(); tree.add(fol);
  [[0, 1.55, 0, 0.38, 'leaf'], [0.17, 1.28, 0.12, 0.28, 'leaf2'], [-0.15, 1.88, -0.05, 0.27, 'leaf2'], [-0.12, 1.3, -0.1, 0.22, 'leaf']].forEach(([x, y, z, r, c]) => add(fol, G(new THREE.IcosahedronGeometry(r, 0)), M(c, { flatShading: true }), x, y, z));

  // bookshelf (skills) + lego on top
  const shelf = piece('shelf', -2.95, 0, -0.75);
  add(shelf, rbox(0.55, 2.7, 0.08, 0.025), M('wood'), 0, 1.35, -0.91);
  add(shelf, rbox(0.55, 2.7, 0.08, 0.025), M('wood'), 0, 1.35, 0.91);
  add(shelf, rbox(0.6, 0.08, 1.98, 0.025), M('wood'), 0, 2.66, 0);
  add(shelf, rbox(0.55, 0.12, 1.9, 0.02), M('woodDark'), 0, 0.06, 0);
  add(shelf, box(0.03, 2.55, 1.78), M('woodDark'), -0.255, 1.35, 0);
  [0.75, 1.4, 2.05].forEach((y) => add(shelf, rbox(0.5, 0.05, 1.78, 0.015), M('wood'), 0, y, 0));
  const rb = rng(11), bookCols = ['a1', 'a2', 'a3', 'a4', 'a5', 'white', 'dark', 'beige'];
  [0.12, 0.775, 1.425, 2.075].forEach((y0, row) => {
    let z = -0.84; const end = row === 3 ? 0.25 : 0.84;
    while (z < end) {
      const w = 0.07 + rb() * 0.07, h = 0.36 + rb() * 0.16;
      if (z + w > end) break;
      const lean = rb() < 0.08 && z > -0.5;
      add(shelf, box(0.34, h, w), M(bookCols[Math.floor(rb() * bookCols.length)]), 0.02, y0 + h / 2 + (lean ? -0.02 : 0), z + w / 2, { rx: lean ? 0.25 : 0 });
      z += w + (lean ? 0.06 : 0.004); if (rb() < 0.07) z += 0.12;
    }
  });
  add(shelf, G(new THREE.CylinderGeometry(0.08, 0.06, 0.12, 10)), M('cabinet'), 0.02, 2.135, 0.55);
  add(shelf, G(new THREE.IcosahedronGeometry(0.1, 0)), M('leaf', { flatShading: true }), 0.02, 2.25, 0.55);

  const lego = piece('lego', -2.95, 2.7, -0.75);
  const U = 0.1, studGeo = G(new THREE.CylinderGeometry(0.03, 0.03, 0.036, 10));
  function brick(parent, nx, nz, col, x, y, z, ry = 0, hgt = 0.12) {
    const b = new THREE.Group(); b.position.set(x, y, z); b.rotation.y = ry; parent.add(b);
    add(b, rbox(nx * U - 0.004, hgt, nz * U - 0.004, 0.012), M(col, { roughness: 0.35 }), 0, hgt / 2, 0);
    for (let i = 0; i < nx; i++) for (let j = 0; j < nz; j++) add(b, studGeo, M(col, { roughness: 0.35 }), (i - (nx - 1) / 2) * U, hgt + 0.018, (j - (nz - 1) / 2) * U, { cast: false });
    return b;
  }
  add(lego, rbox(0.5, 0.03, 1.5, 0.01), M('a4', { roughness: 0.35 }), 0, 0.015, 0);
  ['a1', 'a3', 'a2', 'a3', 'a1', 'white'].forEach((c, i) => brick(lego, 2, 2, c, 0, 0.03 + i * 0.12, -0.5, i % 2 ? 0.3 : 0));
  [0, 1, 2].forEach((lv) => { brick(lego, 2, 4, lv === 1 ? 'a1' : 'white', 0.02, 0.03 + lv * 0.12, 0.15); });
  const roof1 = add(lego, rbox(0.14, 0.03, 0.46, 0.01), M('a2', { roughness: 0.35 }), 0.07, 0.43, 0.15, { rz: -0.7 });
  const roof2 = add(lego, rbox(0.14, 0.03, 0.46, 0.01), M('a2', { roughness: 0.35 }), -0.03, 0.43, 0.15, { rz: 0.7 });
  brick(lego, 1, 1, 'trunk', 0, 0.03, 0.55); brick(lego, 2, 2, 'leaf', 0, 0.15, 0.55);
  const bigBrick = piece(null, 0.55, 0, 2.55, 0.5);
  brick(bigBrick, 2, 4, 'a1', 0, 0, 0).scale.setScalar(1.9);

  // certificates on left wall
  const certs = piece('certs', -3.22, 2.5, 1.65);
  [[0.33, -0.42, 'a1'], [0.33, 0.42, 'a1'], [-0.33, -0.42, 'a1'], [-0.33, 0.42, 'a4']].forEach(([y, z, seal]) => {
    add(certs, rbox(0.05, 0.56, 0.72, 0.02), M('frame'), 0, y, z);
    add(certs, G(new THREE.PlaneGeometry(0.6, 0.44)), M('white'), 0.028, y, z, { ry: Math.PI / 2, cast: false });
    add(certs, box(0.004, 0.022, 0.34), M('dark'), 0.031, y + 0.12, z, { cast: false });
    add(certs, box(0.004, 0.014, 0.42), M('beigeDark'), 0.031, y + 0.05, z, { cast: false });
    add(certs, box(0.004, 0.014, 0.3), M('beigeDark'), 0.031, y + 0.0, z - 0.06, { cast: false });
    add(certs, G(new THREE.CylinderGeometry(0.05, 0.05, 0.012, 18)), M(seal), 0.034, y - 0.11, z + 0.18, { rz: Math.PI / 2, cast: false });
  });

  // beanbag
  const bean = piece(null, 2.25, 0, 1.85);
  add(bean, G(new THREE.SphereGeometry(0.62, 14, 10)), M('beanbag', { roughness: 0.9 }), 0, 0.34, 0, { s: [1, 0.58, 1] });
  add(bean, G(new THREE.SphereGeometry(0.36, 12, 8)), M('beanbag', { roughness: 0.9 }), -0.2, 0.62, -0.25, { s: [1, 0.55, 0.8] });

  // floating shadow
  if (opts.shadowBlob !== false) {
    const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
    const gr = x.createRadialGradient(64, 64, 4, 64, 64, 64); gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    x.fillStyle = gr; x.fillRect(0, 0, 128, 128);
    const t = new THREE.CanvasTexture(c); geos.add(t);
    const blob = new THREE.Mesh(G(new THREE.PlaneGeometry(11, 11)), new THREE.MeshBasicMaterial({ map: t, transparent: true, depthWrite: false, opacity: opts.blobOpacity ?? 0.35 }));
    blob.rotation.x = -Math.PI / 2; blob.position.y = -1.1; blob.raycast = () => {}; scene.add(blob);
    var blobMesh = blob;
  }

  // ---------- lights ----------
  const hemi = new THREE.HemisphereLight(P.hemiDay, P.floor, 1.1); scene.add(hemi);
  const key = new THREE.DirectionalLight('#fff1dc', 1.8); key.position.set(6, 10, 7); key.castShadow = true;
  key.shadow.mapSize.set(2048, 2048); Object.assign(key.shadow.camera, { left: -7, right: 7, top: 7, bottom: -7, near: 1, far: 30 });
  key.shadow.bias = -0.0004; key.shadow.normalBias = 0.03; scene.add(key); scene.add(key.target);
  const spot = new THREE.SpotLight('#ffd9a0', 2.2, 0, 0.36, 0.3, 0); spot.position.set(WCX + 1.4, 6.2, Z0 - 4.4);
  spot.target.position.set(WCX - 0.7, 0, -0.4); spot.castShadow = true; spot.shadow.mapSize.set(1024, 1024); spot.shadow.bias = -0.0006; spot.shadow.normalBias = 0.03;
  scene.add(spot); scene.add(spot.target);
  const lampLight = new THREE.PointLight('#ffb35c', 0, 0, 2); const lampPos = new V3(); scene.add(lampLight);
  const screenLight = new THREE.PointLight(P.screenGlow || '#7fd8ff', 0, 0, 2); screenLight.position.set(-2.3, 1.6, -1.9); scene.add(screenLight);
  const ledLight = new THREE.PointLight(P.led, 0, 0, 1); ledLight.position.set(-2.2, 3.7, -2.2); scene.add(ledLight);
  const ledLight2 = new THREE.PointLight(P.led, 0, 0, 1); ledLight2.position.set(2.4, 3.7, -2.6); scene.add(ledLight2);

  const TH = {
    hemiSky: [C(P.hemiDay), C(P.hemiNight)], hemiGround: [C(P.floor), C('#1b1830')], hemiI: [1.15, 0.52],
    keyC: [C('#fff1dc'), C('#8ea2ff')], keyI: [1.85, 0.36], spotC: [C('#ffd9a0'), C('#a9bbff')], spotI: [1.6, 0.7],
    lampI: [0, 1.6], screenI: [0.1, 1.4], ledI: [0, 1.5], ledE: [0, 2.8], bulbE: [0.2, 4], scr: [0.82, 1.0],
    skyTop: [C(P.skyDayTop), C(P.skyNightTop)], skyBot: [C(P.skyDayBot), C(P.skyNightBot)],
  };
  const tmpC = new THREE.Color();
  const lc = (pair, n) => tmpC.copy(pair[0]).lerp(pair[1], n);
  function applyTheme(n) {
    hemi.color.copy(lc(TH.hemiSky, n)); hemi.groundColor.copy(lc(TH.hemiGround, n)); hemi.intensity = lerp(TH.hemiI[0], TH.hemiI[1], n);
    key.color.copy(lc(TH.keyC, n)); key.intensity = lerp(TH.keyI[0], TH.keyI[1], n);
    spot.color.copy(lc(TH.spotC, n)); spot.intensity = lerp(TH.spotI[0], TH.spotI[1], n);
    lampLight.intensity = lerp(TH.lampI[0], TH.lampI[1], n); screenLight.intensity = lerp(TH.screenI[0], TH.screenI[1], n);
    ledLight.intensity = ledLight2.intensity = lerp(TH.ledI[0], TH.ledI[1], n); ledMat.emissiveIntensity = lerp(TH.ledE[0], TH.ledE[1], n);
    bulbMat.emissiveIntensity = lerp(TH.bulbE[0], TH.bulbE[1], n);
    screenMat.color.setScalar(lerp(TH.scr[0], TH.scr[1], n)); swMat.color.setScalar(lerp(TH.scr[0], TH.scr[1], n));
    skyMat.uniforms.top.value.copy(lc(TH.skyTop, n)); skyMat.uniforms.bot.value.copy(lc(TH.skyBot, n));
    // sun sets, moon rises
    const a = n * Math.PI;
    sun.position.set(0.45 + Math.sin(a) * 0.35, lerp(0.45, -1.05, easeInOut(Math.min(1, n * 1.4))), -0.42);
    sunHalo.position.set(sun.position.x, sun.position.y, -0.44);
    const m = clamp((n - 0.25) / 0.75, 0, 1);
    moon.position.set(-0.55 + (1 - m) * 0.3, lerp(-1.05, 0.42, easeInOut(m)), -0.42);
    cloudMat.opacity = 1 - n; clouds.visible = n < 0.99; starMat.opacity = clamp((n - 0.4) / 0.6, 0, 1); stars.visible = n > 0.4;
    if (blobMesh) blobMesh.material.opacity = (opts.blobOpacity ?? 0.35) * lerp(1, 0.6, n);
  }
  let themeP = opts.dark ? 1 : 0, themeTarget = themeP; applyTheme(themeP);

  // ---------- camera ----------
  const camera = isIso ? new THREE.OrthographicCamera(-1, 1, 1, -1, 0.1, 200) : new THREE.PerspectiveCamera(opts.fov || 30, 1, 0.1, 200);
  const baseTarget = new V3(...(opts.target || [0, 1.45, 0]));
  const base = { yaw: opts.yaw ?? Math.PI / 4, pitch: opts.pitch ?? 0.5, dist: 22, zoom: 1 };
  const cur = { t: baseTarget.clone(), yaw: base.yaw, pitch: base.pitch, dist: 22, zoom: 1 };
  const des = { t: baseTarget.clone(), yaw: 0, pitch: 0, dist: 22, zoom: 1 };
  const drag = { yaw: 0, pitch: 0 };
  let viewH = 10, focusId = null;
  function resize() {
    const w = container.clientWidth || 1, h = container.clientHeight || 1, asp = w / h;
    renderer.setSize(w, h, false);
    const fs = opts.fitScale || 1;
    if (isIso) {
      viewH = Math.max(9.2, 11.8 / asp) * fs;
      Object.assign(camera, { left: (-viewH * asp) / 2, right: (viewH * asp) / 2, top: viewH / 2, bottom: -viewH / 2 });
      base.dist = 30;
    } else {
      camera.aspect = asp; const tf = Math.tan(THREE.MathUtils.degToRad(camera.fov / 2));
      base.dist = Math.max(4.7 / tf, 6.1 / (tf * asp)) * fs;
    }
    camera.updateProjectionMatrix();
  }
  resize();
  cur.dist = base.dist;

  // ---------- interaction ----------
  const raycaster = new THREE.Raycaster(); const ndc = new THREE.Vector2();
  const ptr = { x: 0, y: 0, nx: 0, ny: 0, inside: false, down: null, dragging: false, moved: true };
  let hoverId = null;
  function pick(nx, ny) {
    ndc.set(nx, -ny); raycaster.setFromCamera(ndc, camera);
    const hits = raycaster.intersectObject(world, true);
    for (const h of hits) { let o = h.object; if (!o.visible) continue; while (o) { if (o.userData && o.userData.id) return o.userData.id; o = o.parent; } return null; }
    return null;
  }
  function setHover(id) {
    if (id === hoverId) return; hoverId = id;
    canvas.style.cursor = id ? 'pointer' : ptr.dragging ? 'grabbing' : 'grab';
    opts.onHover && opts.onHover(id);
  }
  function localXY(e) { const r = canvas.getBoundingClientRect(); return [e.clientX - r.left, e.clientY - r.top, r.width, r.height]; }
  const onMove = (e) => {
    const [x, y, w, h] = localXY(e); Object.assign(ptr, { x, y, nx: (x / w) * 2 - 1, ny: (y / h) * 2 - 1, inside: true, moved: true });
    if (ptr.down) {
      const dx = e.clientX - ptr.down.x, dy = e.clientY - ptr.down.y;
      if (!ptr.dragging && Math.hypot(dx, dy) > 6) { ptr.dragging = true; canvas.style.cursor = 'grabbing'; }
      if (ptr.dragging && !focusId) { drag.yaw = clamp(ptr.down.yaw - dx * 0.004, -0.3, 0.3); drag.pitch = clamp(ptr.down.pitch + dy * 0.003, -0.18, 0.22); }
    }
    if (opts.tipEl) opts.tipEl.style.translate = `${x}px ${y}px`;
  };
  const onDown = (e) => { ptr.down = { x: e.clientX, y: e.clientY, yaw: drag.yaw, pitch: drag.pitch }; try { canvas.setPointerCapture(e.pointerId); } catch (_) {} };
  const onUp = (e) => {
    if (ptr.down && !ptr.dragging) { const [x, y, w, h] = localXY(e); const id = pick((x / w) * 2 - 1, (y / h) * 2 - 1); opts.onSelect && opts.onSelect(id); }
    ptr.down = null; ptr.dragging = false; canvas.style.cursor = hoverId ? 'pointer' : 'grab';
  };
  const onLeave = () => { ptr.inside = false; setHover(null); };
  canvas.addEventListener('pointermove', onMove); canvas.addEventListener('pointerdown', onDown);
  canvas.addEventListener('pointerup', onUp); canvas.addEventListener('pointerleave', onLeave);
  const ro = new ResizeObserver(resize); ro.observe(container);
  let visible = true;
  const io = new IntersectionObserver((en) => { visible = en[0].isIntersecting; }); io.observe(container);

  // ---------- loop ----------
  const t0 = performance.now(); let last = t0, raf = 0, scrTimer = 0, frameN = 0;
  scr.draw(0);
  function frame(now) {
    raf = requestAnimationFrame(frame); step(now);
  }
  let lastStep = performance.now();
  const watchdog = setInterval(() => { const n = performance.now(); if (n - lastStep > 120) step(n); }, 40);
  function step(now) {
    lastStep = now;
    const dt = Math.min(0.1, (now - last) / 1000); last = now;
    if (!visible) return;
    const t = (now - t0) / 1000; frameN++;
    if (themeP !== themeTarget) { const s = Math.sign(themeTarget - themeP); themeP = clamp(themeP + (s * dt) / 1.5, 0, 1); if ((s > 0 && themeP >= themeTarget) || (s < 0 && themeP <= themeTarget)) themeP = themeTarget; applyTheme(easeInOut(themeP)); }
    if (ptr.inside && !ptr.dragging && (ptr.moved || frameN % 8 === 0)) { setHover(pick(ptr.nx, ptr.ny)); ptr.moved = false; }
    const k = 1 - Math.exp(-dt * 10);
    for (const o of animated) {
      const u = o.userData;
      const p = reduce ? 1 : clamp((t - u.delay) / 0.75, 0, 1);
      const e = p >= 1 ? 1 : easeOutBack(p);
      u.h += (((u.id && (u.id === hoverId || u.id === focusId)) ? 1 : 0) - u.h) * k;
      o.visible = p > 0;
      if (u.kind === 'scale') { o.scale.setScalar(Math.max(0.0001, e)); }
      else { o.position.y = u.baseY + (1 - e) * 2.6 + u.h * 0.07; o.scale.setScalar(1 + u.h * 0.035); }
    }
    outside.visible = shell.visible && (reduce || t > 0.6);
    spin.rotation.y += dt * 0.35;
    fol.rotation.z = Math.sin(t * 1.1) * 0.025; fol.rotation.x = Math.sin(t * 0.8) * 0.02;
    palm.rotation.z = Math.sin(t * 1.4) * 0.04;
    scrTimer += dt; if (scrTimer > 0.25) { scrTimer = 0; scr.draw(t); }
    if (opts.bob) world.position.y = Math.sin(t * 0.9) * opts.bob;
    head.getWorldPosition(lampPos); lampLight.position.copy(lampPos).add(new V3(0.05, -0.15, 0.05));
    // camera
    const f = opts.cameraFocus !== false && focusId && FOCUS[focusId];
    if (f) {
      des.t.set(...f.p); des.yaw = f.yaw + ptr.nx * 0.03; des.pitch = f.pitch; des.dist = isIso ? base.dist : f.dist * (opts.focusDistScale || 1); des.zoom = isIso ? f.zoom * (opts.focusZoomScale || 1) : 1;
      if (opts.focusShift) {
        const halfW = isIso ? (camera.right - camera.left) / 2 / des.zoom : des.dist * Math.tan(THREE.MathUtils.degToRad(camera.fov / 2)) * camera.aspect;
        const sh = opts.focusShift * halfW; des.t.x += Math.cos(des.yaw) * sh; des.t.z -= Math.sin(des.yaw) * sh;
      }
    }
    else { des.t.copy(baseTarget); des.yaw = base.yaw + drag.yaw + (ptr.inside ? ptr.nx * 0.07 : 0); des.pitch = base.pitch + drag.pitch - (ptr.inside ? ptr.ny * 0.035 : 0); des.dist = base.dist; des.zoom = 1; }
    const kc = 1 - Math.exp(-dt * (f ? 3.2 : 4));
    cur.t.lerp(des.t, kc); cur.yaw += (des.yaw - cur.yaw) * kc; cur.pitch += (des.pitch - cur.pitch) * kc; cur.dist += (des.dist - cur.dist) * kc; cur.zoom += (des.zoom - cur.zoom) * kc;
    camera.position.set(cur.t.x + Math.sin(cur.yaw) * Math.cos(cur.pitch) * cur.dist, cur.t.y + Math.sin(cur.pitch) * cur.dist, cur.t.z + Math.cos(cur.yaw) * Math.cos(cur.pitch) * cur.dist);
    camera.lookAt(cur.t);
    if (isIso && Math.abs(camera.zoom - cur.zoom) > 1e-4) { camera.zoom = cur.zoom; camera.updateProjectionMatrix(); }
    renderer.render(scene, camera);
  }
  raf = requestAnimationFrame(frame);
  opts.onReady && opts.onReady();

  return {
    setTheme(dark, instant) { themeTarget = dark ? 1 : 0; if (instant) { themeP = themeTarget; applyTheme(themeP); } },
    focus(id) { focusId = id && FOCUS[id] ? id : null; },
    ids: Object.keys(inter),
    dispose() {
      cancelAnimationFrame(raf); clearInterval(watchdog); ro.disconnect(); io.disconnect();
      canvas.removeEventListener('pointermove', onMove); canvas.removeEventListener('pointerdown', onDown);
      canvas.removeEventListener('pointerup', onUp); canvas.removeEventListener('pointerleave', onLeave);
      geos.forEach((g) => g.dispose && g.dispose()); Object.values(mats).forEach((m) => m.dispose());
      renderer.dispose(); canvas.remove();
    },
  };
}

function makeScreen(P) {
  const c = document.createElement('canvas'); c.width = 384; c.height = 288;
  const x = c.getContext('2d'); const tex = new THREE.CanvasTexture(c); tex.colorSpace = THREE.SRGBColorSpace; tex.anisotropy = 4;
  const code = [
    ['#c792ea', 'def ', '#82aaff', 'best_price', '#e0e0e0', '(sku):'],
    ['#e0e0e0', '    hist = ', '#82aaff', 'load_sales', '#e0e0e0', '(sku)'],
    ['#e0e0e0', '    e = ', '#82aaff', 'fit_elasticity', '#e0e0e0', '(hist)'],
    ['#c792ea', '    for ', '#e0e0e0', 'p ', '#c792ea', 'in ', '#82aaff', 'prices', '#e0e0e0', '(sku):'],
    ['#e0e0e0', '        m[p] = ', '#82aaff', 'margin', '#e0e0e0', '(p, e)'],
    ['#c792ea', '    return ', '#82aaff', 'argmax', '#e0e0e0', '(m)'],
    ['#6b7394', '# promo optimiser · v2'],
  ];
  function draw(t) {
    x.fillStyle = P.screenBg; x.fillRect(0, 0, 384, 288);
    x.fillStyle = 'rgba(255,255,255,0.07)'; x.fillRect(0, 0, 384, 30);
    [P.a1, P.a3, P.a4].forEach((col, i) => { x.fillStyle = col; x.beginPath(); x.arc(18 + i * 16, 15, 5, 0, 7); x.fill(); });
    x.font = '600 14px ui-monospace, Menlo, monospace'; x.fillStyle = 'rgba(255,255,255,0.65)';
    const mode = Math.floor(t / 7) % 2;
    if (mode === 0) {
      x.fillText('retail_iq / supplier_sales', 76, 20);
      for (let i = 0; i < 10; i++) {
        const h = 50 + 120 * (0.5 + 0.5 * Math.sin(i * 1.27 + t * 0.9));
        x.fillStyle = [P.a3, P.a2, P.a4, P.a5][i % 4]; x.fillRect(26 + i * 34, 262 - h, 22, h);
      }
      x.strokeStyle = P.a1; x.lineWidth = 3; x.beginPath();
      for (let i = 0; i < 10; i++) { const y = 120 - 40 * Math.sin(i * 0.7 + t * 0.6); i ? x.lineTo(37 + i * 34, y) : x.moveTo(37, y); }
      x.stroke();
    } else {
      x.fillText('promo_optimiser.py', 76, 20);
      x.font = '15px ui-monospace, Menlo, monospace';
      const shown = Math.min(code.length, 1 + Math.floor((t % 7) * 1.6));
      code.slice(0, shown).forEach((parts, li) => { let px = 18; for (let i = 0; i < parts.length; i += 2) { x.fillStyle = parts[i]; x.fillText(parts[i + 1], px, 62 + li * 28); px += x.measureText(parts[i + 1]).width; } });
      if (Math.floor(t * 2) % 2) { x.fillStyle = P.a3; x.fillRect(18, 48 + shown * 28, 10, 18); }
    }
    x.fillStyle = 'rgba(0,0,0,0.13)'; for (let y = 0; y < 288; y += 3) x.fillRect(0, y, 384, 1);
    tex.needsUpdate = true;
  }
  return { tex, draw };
}

function makeSwitchScreen(P) {
  const c = document.createElement('canvas'); c.width = 160; c.height = 90; const x = c.getContext('2d');
  const g = x.createLinearGradient(0, 0, 0, 90); g.addColorStop(0, '#7fd0ff'); g.addColorStop(1, '#d9f3ff'); x.fillStyle = g; x.fillRect(0, 0, 160, 90);
  x.fillStyle = '#ffd24a'; x.fillRect(120, 12, 16, 16);
  const hs = [5, 5, 4, 4, 3, 3, 4, 5, 5, 6, 6, 5, 4, 4, 5, 5];
  hs.forEach((h, i) => { for (let j = 0; j < h; j++) { x.fillStyle = j === h - 1 ? '#5cc46e' : (j === h - 2 ? '#8a5a3a' : '#6b4630'); x.fillRect(i * 10, 90 - (j + 1) * 10, 10, 10); } });
  x.fillStyle = '#2f8f58'; x.fillRect(40, 30, 20, 20); x.fillStyle = '#6b4630'; x.fillRect(47, 50, 6, 10);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.magFilter = THREE.NearestFilter; return t;
}
